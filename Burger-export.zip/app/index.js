import clock from "clock";
import { HeartRateSensor } from "heart-rate";
import document from "document";
import { preferences } from "user-settings";
import { battery } from "power"; // import battery level (see line26)
import userActivity from "user-activity";
import * as util from "../common/utils";

// Update the clock every minute
clock.granularity = "seconds";

// Get a handle on the <text> element
const time = document.getElementById("time");
const burgerIcon = document.getElementById("burger");

const myClockSeconds = document.getElementById("myClockSeconds")
const mySteps = document.getElementById("mySteps");
const myHR  = document.getElementById("myHR");
const myBatteryLevel = document.getElementById("myBatteryLevel");
const todayDate = document.getElementById("todayDate");
const day = document.getElementById("day");
const condiment1 = document.getElementById("condiment1");
const condiment2 = document.getElementById("condiment2");



//// Grab heart rate sensor and value
const hrm = new HeartRateSensor();
hrm.onreading = function(){
  myHR.text = `${hrm.heartRate}`;
}
hrm.start();

console.log("Hr" + myHR.text);


function animateIcon(type, frameCount, delay, icon, time){
  let frame = 1;
  let frameCount = frameCount;
  let orange = "#FF4500";
  
  setInterval(function(){
    icon.href = `${type}/${type}${frame}.png`;
    frame++;
    if(frame > frameCount){
      frame = 1;
    }
  },delay)
}

animateIcon("burger", 3, 600, burgerIcon, time);
animateIcon("condiment", 2, 600, condiment1, time);
animateIcon("condiment", 2, 600, condiment2, time);

// Update the <text> element every tick with the current time
clock.ontick = (evt) => {
  let today = evt.date;
  let hours = today.getHours();
  if (preferences.clockDisplay === "12h") {
    // 12h format
    hours = hours % 12 || 12;
  } else {
    // 24h format
    hours = util.zeroPad(hours);
  }
  let mins = util.zeroPad(today.getMinutes());
  let seconds = today.getSeconds();
  
  time.text = `${hours}:${mins}`;
  if (seconds % 2 == 0){
    time.style.fill = "#FFD700";
    myClockSeconds.style.fill = "#FFD700";
    day.style.fill = "#FFD700";
  }
  else{
    time.style.fill = "#FF0000";
    myClockSeconds.style.fill = "#FF0000";
    day.style.fill = "#FF0000";
  }
  
  
  myClockSeconds.text = "(" + `${seconds}` + ")";
  
  let shortDate = evt.date.toString().split(" ",3);
  day.text = shortDate[0];
  
  
  ////// Steps inside tick handler

  mySteps.text = `${userActivity.today.adjusted["steps"] || 0}`;
  console.log("num steps" + mySteps.text);
  
    ////// Battery inside tick handler
  myBatteryLevel.text = `${battery.chargeLevel}%`;
  console.log("battery level:" + myBatteryLevel.text);

   ////// Today's Date inside tick handler
  
  shortDate = evt.date.toString().split(" ",3);
  todayDate.text = shortDate[1] + " " + shortDate[2];
  
  console.log(todayDate.text);
}
